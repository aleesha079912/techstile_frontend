import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:techstile_frontend/core/services/factory_service.dart'; 
import 'package:techstile_frontend/core/utils/theme.dart';

class AddFactoryScreen extends StatefulWidget {
  const AddFactoryScreen({super.key});

  @override
  State<AddFactoryScreen> createState() => _AddFactoryScreenState();
}

class _AddFactoryScreenState extends State<AddFactoryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final existing = Get.arguments;
    if (existing != null) {
      _nameController.text = existing.name;
      _addressController.text = existing.address;
      _cityController.text = existing.city;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final controller = Get.find<FactoryController>();
    final existing = Get.arguments;

    final factoryData = {
      "name": _nameController.text.trim(),
      "address": _addressController.text.trim(),
      "city": _cityController.text.trim(),
    };

    try {
      bool success = false;
      if (existing != null) {
        success = await controller.updateFactory(existing.id, factoryData);
      } else {
        success = await controller.addFactory(factoryData);
      }

      if (success) {
        Get.back();
        Get.snackbar(
          "Success", 
          existing != null ? "Factory updated!" : "Factory added!",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: AppTheme.success.withOpacity(0.8),
          colorText: AppTheme.textSecondary,
        );
      }
    } catch (e) {
      Get.snackbar("Error", "Something went wrong: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = Get.arguments;
    
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: _buildAppBar(existing != null),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            children: [
              _buildHeroCard(existing != null),
              const SizedBox(height: 20),
              _buildSectionLabel("Factory Details"),
              const SizedBox(height: 10),
              _buildField(
                controller: _nameController,
                label: "Factory Name",
                hint: "e.g. Al-Kareem Textiles Ltd.",
                icon: Icons.domain_rounded,
                validator: (v) => (v == null || v.trim().isEmpty) ? "Factory name is required" : null,
              ),
              const SizedBox(height: 10),
              _buildField(
                controller: _addressController,
                label: "Address",
                hint: "e.g. 45-B Industrial Zone",
                icon: Icons.location_on_rounded,
                validator: (v) => (v == null || v.trim().isEmpty) ? "Address is required" : null,
              ),
              const SizedBox(height: 10),
              _buildField(
                controller: _cityController,
                label: "City",
                hint: "e.g. Lahore",
                icon: Icons.public_rounded,
                validator: (v) => (v == null || v.trim().isEmpty) ? "City is required" : null,
              ),
              const SizedBox(height: 28),
              _buildSaveButton(),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(bool isEdit) {
    return AppBar(
      backgroundColor: AppTheme.primary,
      elevation: 0,
      centerTitle: false,
      leading: IconButton(
        onPressed: () => Get.back(),
        icon: const Icon(Icons.arrow_back, color: AppTheme.secondary, size: 20),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            isEdit ? "Edit Factory" : "Add Factory",
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            isEdit ? "Update existing unit details" : "Register a new production unit",
            style: TextStyle(
              color: AppTheme.textSecondary.withOpacity(0.7),
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeroCard(bool isEdit) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.secondary,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primary.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: AppTheme.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              isEdit ? Icons.edit_note_rounded : Icons.factory_rounded,
              color: AppTheme.primary,
              size: 26,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isEdit ? "Update Factory Info" : "New Factory Registration",
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  isEdit
                      ? "Modify details and save changes to server"
                      : "Fill in the details to add a factory to your network",
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11.5,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label) => Text(
        label.toUpperCase(),
        style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w700,
            color: AppTheme.textPrimary,
            letterSpacing: 0.9),
      );

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.secondary,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: AppTheme.primary.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: TextFormField(
        controller: controller,
        validator: validator,
        style: const TextStyle(fontSize: 14, color: AppTheme.textPrimary),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w600),
          prefixIcon: Container(
            margin: const EdgeInsets.all(10),
            width: 34,
            height: 34,
            decoration: BoxDecoration(
                color: AppTheme.secondary,
                borderRadius: BorderRadius.circular(9)),
            child: Icon(icon, color: AppTheme.primary, size: 17),
          ),
          border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16),
              borderSide:
                  const BorderSide(color: AppTheme.primary, width: 1.5)),
          filled: true,
          fillColor: AppTheme.secondary,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildSaveButton() {
    final controller = Get.find<FactoryController>();

    return Obx(() => Container(
          decoration: BoxDecoration(
            color: AppTheme.primary,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                  color: AppTheme.primary.withOpacity(0.35),
                  blurRadius: 16,
                  offset: const Offset(0, 6))
            ],
          ),
          child: Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: controller.isLoading.value ? null : _submit,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Center(
                  child: controller.isLoading.value
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              color: AppTheme.secondary, strokeWidth: 2))
                      : const Column(
                          children: [
                            Text("Save Factory",
                                style: TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600)),
                            SizedBox(height: 2),
                            Text("All fields are required",
                                style: TextStyle(
                                    color: AppTheme.textneutral,
                                    fontSize: 10.5)),
                          ],
                        ),
                ),
              ),
            ),
          ),
        ));
  }
}