import '../auth_service.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:techstile_frontend/core/services/machines_service.dart';

class ManagerDashboardService {
  final String baseUrl = "http://localhost:8000/api/manager";

  Future<Map<String, dynamic>> getDashboard(
    dynamic factoryId, {
    String? period,
  }) async {
    final query = (period != null && period.isNotEmpty)
        ? "?period=${Uri.encodeComponent(period)}"
        : "";
    final response = await http.get(
      Uri.parse("$baseUrl/dashboard/$factoryId$query"),
      headers: AuthService.authHeaders,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception("Could not load manager dashboard");
  }

  // 0 = Sunday ... 6 = Saturday
  Future<Map<String, dynamic>> updateWeekStartDay(
    dynamic factoryId,
    int weekStartDay,
  ) async {
    final response = await http.put(
      Uri.parse("$baseUrl/week-start-day/$factoryId"),
      headers: {...AuthService.authHeaders, 'Content-Type': 'application/json'},
      body: jsonEncode({'week_start_day': weekStartDay}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    throw Exception("Could not update week start day");
  }

  Future<List<Machine>> getMachines(dynamic factoryId) async {
    final response = await http.get(
      Uri.parse("$baseUrl/machines/$factoryId"),
      headers: AuthService.authHeaders,
    );
    if (response.statusCode == 200) {
      final List rawList = jsonDecode(response.body)['machines'] ?? [];
      return rawList.map((json) => Machine.fromJson(json)).toList();
    }
    throw Exception("Could not load machines");
  }

  Future<List<dynamic>> getEmployees(dynamic factoryId) async {
    final response = await http.get(
      Uri.parse("$baseUrl/employees/$factoryId"),
      headers: AuthService.authHeaders,
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body)['employees'] ?? [];
    }
    throw Exception("Could not load employees");
  }

  Future<Map<String, dynamic>> getPayments(dynamic factoryId) async {
    final response = await http.get(
      Uri.parse("$baseUrl/payments/$factoryId"),
      headers: AuthService.authHeaders,
    );
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    String msg = "Could not load payments";
    try {
      final body = jsonDecode(response.body);
      if (body is Map && body['message'] != null) {
        msg = body['message'];
      }
    } catch (_) {}
    throw Exception(msg);
  }
}
