import 'package:http/http.dart' as http;
import 'dart:convert';
import 'auth_service.dart';

class RoleService {
  final String baseUrl = "http://localhost:8000/api/roles";

  // 1. Fetch Roles
  Future<List<dynamic>> getRoles() async {
    final response = await http.get(
      Uri.parse('$baseUrl/all'),
      headers: AuthService.authHeaders,
    );
    if (response.statusCode == 200) {
      return json.decode(response.body)['data'];
    } else {
      throw Exception('Failed to load roles');
    }
  }

  Future<Map<String, dynamic>> addRole(String name) async {
    var response = await http.post(
      Uri.parse('$baseUrl/add'),
      headers: AuthService.authHeaders,
      body: json.encode({"name": name}),
    );

    var data = jsonDecode(response.body);

    if (data['status'] == true) {
      return {'success': true, 'message': 'Role added successfully'};
    }

    return {
      'success': false,
      'message': data['errors']?['name']?[0] ?? 'Role already exists',
    };
  }

  // delete role
  Future<bool> deleteRole(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/delete/$id'),
      headers: AuthService.authHeaders,
    );
    return response.statusCode == 200;
  }

  // Role update
  Future<bool> updateRole(int id, String newName) async {
    final response = await http.put(
      Uri.parse('$baseUrl/update/$id'),
      headers: AuthService.authHeaders,
      body: json.encode({"name": newName}),
    );
    return response.statusCode == 200;
  }

  //fetch Permissions list
  Future<List<dynamic>> getAllPermissions() async {
    final response = await http.get(
      Uri.parse('http://localhost:8000/api/permissions/all'),
      headers: AuthService.authHeaders,
    );
    return json.decode(response.body)['data'];
  }

  // Fetch Role present permissions
  Future<List<dynamic>> getRolePermissions(int roleId) async {
    final response = await http.get(
      Uri.parse('http://localhost:8000/api/role-permissions/$roleId'),
      headers: AuthService.authHeaders,
    );
    return json.decode(response.body)['data'];
  }

  // Permissions update
  Future<bool> syncPermissions(int roleId, List<int> permIds) async {
    final response = await http.post(
      Uri.parse('http://localhost:8000/api/permissions/sync'),
      headers: AuthService.authHeaders,
      body: json.encode({"role_id": roleId, "permissions": permIds}),
    );
    return response.statusCode == 200;
  }
}
